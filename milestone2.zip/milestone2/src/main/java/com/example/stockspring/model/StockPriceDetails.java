package com.example.stockspring.model;

import java.util.Date;

public class StockPriceDetails {
private int companyCode;
private int stockExchange;
private double currentPrice;
private Date date;
private Date time;

}
