package com.example.stockspring.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.stockspring.model.IpoPlanned;

public interface IpoDao extends JpaRepository<IpoPlanned, Integer> {

}
