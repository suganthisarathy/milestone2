package com.example.stockspring.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.model.IpoPlanned;
import com.example.stockspring.service.IpoService;

@Controller
public class IpoControllerImpl implements IpoController {
	@Autowired
	private IpoService ipoPlanned;
	
	
	
	
	@RequestMapping(value = "/addIpo", method = RequestMethod.POST)
	public String insertIpo(@ModelAttribute("i1")@Valid IpoPlanned ipo,BindingResult result,Model model) throws SQLException {
		if(result.hasErrors()){
			System.out.println("errors");
			System.out.println(result.getAllErrors());
			model.addAttribute("i1",ipo );
			return "IpoDetails";
		}
		ipoPlanned.insertIpo(ipo);
		return "redirect:/ipoList";	
	}

	
	public IpoPlanned updateIpo(IpoPlanned ipo) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@RequestMapping(path="/ipoList")
	public ModelAndView getStockList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("IpoList");
		mv.addObject("IpoList",ipoPlanned.getIpoList());
		return mv;
	}
	@RequestMapping(value = "/addIpo", method = RequestMethod.GET)
	public String getStockForm(ModelMap model) {
		//System.out.println("add employee");
		IpoPlanned i=new IpoPlanned();
		//e.setEmail("sdfsf");
	//	e.setSalary(4564.56f);
		model.addAttribute("i1", i);
		return "IpoDetails";
		
	}
}
