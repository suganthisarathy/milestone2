package com.example.stockspring.controller;

import java.sql.SQLException;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import com.example.stockspring.model.StockExchange;

public interface StockController {
	 
}
